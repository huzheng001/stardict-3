package src;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


public class Po2Tab {
	
	private List lst;
	private String Path;
	private StringBuffer Buffer;
	private static final String SYS_LINE = System.getProperty("line.separator");
	private static final String SYS_SPARATOR = System.getProperty("file.separator");
	
	public Po2Tab(String PoFilePath){
		Path = PoFilePath;
	}
	
	public String getString() {
//		return lst.toString().replace(",", "");
		return Buffer.toString();
	}
	

	public List getList() {
		return lst;
	}
	
	public void OpenFromFile() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(Path), "UTF8"));
			Buffer = new StringBuffer();
			lst = new ArrayList();
			String temp;
			int x = 0;
			while( ( temp = in.readLine()) != null) {
				if (temp.contains("msgid \"")) {
					x++;
					System.out.println("Adding word Nr.:"+String.valueOf(x));
					temp = temp.toLowerCase();
					temp = temp.replace("msgid \"", "");
					temp = temp.replace("\"", "");
					temp = temp.trim();
					temp += "\t";
					temp.replace("  ", "\t");
				}else if(temp.contains("msgstr \"")){
					x++;
					if (!temp.contains("\t")) {
						temp+="\t";
					}
					temp = temp.toLowerCase();
					temp = temp.replace("msgstr \"", "");
					temp = temp.replace("::", "\\n");
					temp = temp.replace("،", "\\n");
					temp = temp.replace("\"", "");
					temp = temp.trim();
					temp = temp.replace(" \\n ", "\\n");
					temp.replace("  ", "\t");
					temp += "\n";
				}
				else{
					temp="";
				}	
				if(temp != "")
				{
					lst.add(temp);
					Buffer.append(temp);
				}
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void OpenFromFile(String Path){
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(Path), "UTF8"));
			Buffer = new StringBuffer();
			lst = new ArrayList();
			String temp;
			int x = 0;
			while( ( temp = in.readLine()) != null) {
				if (temp.contains("msgid \"")) {
					x++;
					System.out.println("Adding word Nr.:"+String.valueOf(x));
					temp = temp.toLowerCase();
					temp = temp.replace("msgid \"", "");
					temp = temp.replace("\"", "");
					temp = temp.trim();
					temp += "\t";
					temp.replace("  ", "\t");
				}else if(temp.contains("msgstr \"")){
					x++;
					if (!temp.contains("\t")) {
						temp+="\t";
					}
					temp = temp.toLowerCase();
					temp = temp.replace("msgstr \"", "");
					temp = temp.replace("::", "\\n");
					temp = temp.replace("،", "\\n");
					temp = temp.replace("\"", "");
					temp = temp.trim();
					temp = temp.replace(" \\n ", "\\n");
					temp.replace("  ", "\t");
					temp += "\n";
				}
				else{
					temp="";
				}	
				if(temp != "")
				{
					lst.add(temp);
					Buffer.append(temp);
				}
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void SaveToFile() {
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(Path.replace(".po", ".tab")), "UTF8")));
			out.write(getString());
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void SaveToFile(String Path){
		try {
			PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(Path), "UTF8")));
			out.write(getString());
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public int getFileLenght() {
		return lst.size();
	}
	
}
