Po2Tab
=================================

Copyright 2006 M. Bashir Al-Noimi

e-mails:	bashir.storm@gmail.com
			hali83@cec.sy
			webmaster@hali-sy.com
Blog: http://www.hali-sy.net/bashir

This software is OSI Certified Open Source Software.
OSI Certified is a certification mark of the Open Source Initiative.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.


Running Po2Tab
=================================

To run Po2Tab from source code you need eclipse 3.2 IDE and JRE more than 1.4.3
eclipse : http://www.eclipse.org/
JRE : http://www.sun.com/ 